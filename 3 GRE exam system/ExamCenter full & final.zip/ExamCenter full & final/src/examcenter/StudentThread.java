
package examcenter;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import static java.lang.System.in;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

class StudentThread extends Thread{
    ObjectInputStream ois=null;
    
    public StudentThread(ObjectInputStream in){
        ois=in;
    }
    public void run(){
        int n=1;
        while(true){
            try {
                FileOutputStream fw=new FileOutputStream(String.format("src/Questions/Question%d",n++));
                BufferedOutputStream bw=new BufferedOutputStream(fw);
                
                byte[] str=((String)ois.readObject()).getBytes();
                bw.write(str);
                bw.flush();
            } catch (IOException ex) {
                System.out.println("Can't read");
                Logger.getLogger(StudentThread.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                System.out.println("Can't read");
                Logger.getLogger(StudentThread.class.getName()).log(Level.SEVERE, null, ex);
            }
        }        
    }
}
