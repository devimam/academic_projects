

package examcenter;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JDialog;
import javax.swing.JOptionPane;


public class AnalyticExam2 extends javax.swing.JFrame {

    int time=30*60;
    ana2thread t;
    ObjectOutputStream out;
    
    String roll;
    
    public AnalyticExam2(String roll) {
        initComponents();
        this.setTitle("GRE Exam");
        try {
            this.roll=roll;
            
            FileReader fr=new FileReader("src/Questions/Question2");
            BufferedReader br=new BufferedReader(fr);
            String s=null;
            while((s=(String)br.readLine())!=null){
                q2.append(s+"\n");
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(AnalyticExam1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(AnalyticExam1.class.getName()).log(Level.SEVERE, null, ex);
        }
        t=new ana2thread(timer,time,this);
        ExecutorService e=Executors.newCachedThreadPool();
        e.execute(t); 
        e.shutdown();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        q2 = new javax.swing.JTextArea();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        answer = new javax.swing.JTextArea();
        nextb = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        timer = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 255));
        jLabel1.setText("Analytic Writing 2:");

        q2.setEditable(false);
        q2.setColumns(20);
        q2.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        q2.setLineWrap(true);
        q2.setRows(1);
        jScrollPane1.setViewportView(q2);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel2.setText("Answer:");

        answer.setColumns(20);
        answer.setRows(5);
        jScrollPane2.setViewportView(answer);

        nextb.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        nextb.setText("Next>>");
        nextb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextbActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setText("Time:");

        timer.setFont(new java.awt.Font("DS-Digital", 1, 36)); // NOI18N
        timer.setForeground(new java.awt.Color(255, 0, 0));
        timer.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        timer.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                timerPropertyChange(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(nextb, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 380, Short.MAX_VALUE)
                    .addComponent(jScrollPane2)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(timer, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 189, Short.MAX_VALUE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(timer, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 65, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(nextb, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void nextbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextbActionPerformed
        // TODO add your handling code here:
        int dig=JOptionPane.showConfirmDialog(this,"Do you want to submit this section?","GRE Exam",JOptionPane.YES_NO_OPTION);
        if(dig==JOptionPane.YES_OPTION){

        try {
            FileWriter fw=new FileWriter("src/Resources/ans"+roll+".txt",true);
            BufferedWriter bw=new BufferedWriter(fw);
            bw.append("Analytic Writing 2:\n\n");
            bw.append(answer.getText()+"\n\n");
            bw.flush();
            t.kill();

        } catch (FileNotFoundException ex) {
            Logger.getLogger(AnalyticExam1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(AnalyticExam1.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        this.setVisible(false);
        VR_q1 page=new VR_q1(roll);
        page.setSize(this.getSize());
        page.out=out;
        page.setVisible(true);
        }
        
        

    }//GEN-LAST:event_nextbActionPerformed

    private void timerPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_timerPropertyChange
        // TODO add your handling code here:
        if(timer.getText().equals("Time is UP!")){
            JOptionPane pane = new JOptionPane("Time is UP!!", JOptionPane.INFORMATION_MESSAGE);
            final JDialog dialog = pane.createDialog(this, "GRE Exam");
            new Thread(new Runnable()
            {
              public void run()
              {
                    try
                    {
                      Thread.sleep(5000);
                      dialog.dispose();

                    }
                    catch ( Throwable th )
                    {
                    }
                }
            }).start(); 
            dialog.setVisible(true);
            try {
                FileWriter fw=new FileWriter("src/Resources/ans"+roll+".txt",true);
                BufferedWriter bw=new BufferedWriter(fw);
                bw.append("Analytic Writing 2:\n\n");
                bw.append(answer.getText()+"\n\n");
                bw.flush();
                t.kill();

            } catch (FileNotFoundException ex) {
                Logger.getLogger(AnalyticExam1.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(AnalyticExam1.class.getName()).log(Level.SEVERE, null, ex);
            }

            this.setVisible(false);
            VR_q1 page=new VR_q1(roll);
            page.setSize(this.getSize());
            page.out=out;
            page.setVisible(true);
        }
    }//GEN-LAST:event_timerPropertyChange
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AnalyticExam2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AnalyticExam2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AnalyticExam2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AnalyticExam2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                ///new AnalyticExam2().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea answer;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton nextb;
    private javax.swing.JTextArea q2;
    private javax.swing.JLabel timer;
    // End of variables declaration//GEN-END:variables
}
