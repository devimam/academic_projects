

package examcenter;


public class ExamCenter {


    public static void main(String[] args) {
        // TODO code application logic here
        new Student().setVisible(true);
    }
    
}
