
package examcenter;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;


class ana2thread extends Thread{
    JFrame f=null;
    
    JLabel l;
    int sec;
    int limit;
    Calendar cal=new GregorianCalendar();
    boolean check=true;
    boolean flag=false;
    
    ana2thread(JLabel lab,int lim,JFrame frame){
        l=lab;
        f=frame;
        limit=lim;
        int h=cal.get(Calendar.HOUR);
        int m=cal.get(Calendar.MINUTE);
        int s=cal.get(Calendar.SECOND);
        sec=h*3600+m*60+s;
    }
    public void kill(){
         check=false;
    }
    
    public void run(){
        while(check){
            int th,tm,ts;
            Calendar cal1=new GregorianCalendar();
            th=cal1.get(Calendar.HOUR);
            tm=cal1.get(Calendar.MINUTE);
            ts=cal1.get(Calendar.SECOND);

            int temps=th*3600+tm*60+ts;
            int diff=temps-sec;
            if(diff>=limit) {
                l.setText("Time is UP!");
                flag=true;
                check=false;
          
            }
            
            
            int hour=diff/3600;
            diff=diff%3600;
            int minute=diff/60;
            diff=diff%60;
            int second=diff;

            l.setText(hour+":"+minute+":"+second);
        }
    }
}
