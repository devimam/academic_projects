
package examcenter;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JDialog;
import javax.swing.JOptionPane;

public class VR_q1 extends javax.swing.JFrame {

    String op1=null;
    String op2=null;
    String op3=null;
    String op4=null;
    String op5=null;
    String op6=null;
    int time=30*60;
    int c=3;
    ObjectOutputStream out;
    
    String roll;
    
    boolean arr[][]={{false,false,false,false,false},{false,false,false,false,false},{false,false,false,false,false},{false,false,false,false,false},{false,false,false,false,false}};
    ExecutorService e;
    VR1thread t;
    
    public VR_q1(String roll) {
        initComponents();
        this.setTitle("GRE Exam");
        try {
            this.roll=roll;
            
            FileReader fr=new FileReader(String.format("src/Questions/Question"+c));
            BufferedReader br=new BufferedReader(fr);
            String s=null;
                
                while((s=(String)br.readLine()).compareTo("Question:")!=0){
                       pass.setText(s);
                   }
                
                if(s.equals("Question:")){
                   s=(String)br.readLine();
                   q3.setText(s);
                }
                
                    s=(String)br.readLine();
                    
                    if(s!=null) opt1.setText(s);
                    s=(String)br.readLine();
                    if(s!=null)opt2.setText(s);
                    s=(String)br.readLine();
                    if(s!=null)opt3.setText(s);
                    s=(String)br.readLine();
                    if(s!=null)opt4.setText(s);
                    s=(String)br.readLine();
                    if(s!=null)opt5.setText(s);
  
        } catch (FileNotFoundException ex) {
            Logger.getLogger(AnalyticExam1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(AnalyticExam1.class.getName()).log(Level.SEVERE, null, ex);
        }
        t=new VR1thread(timer,time,this);
        e=Executors.newCachedThreadPool();
        e.execute(t); 
        
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jCheckBox6 = new javax.swing.JCheckBox();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        pass = new javax.swing.JTextArea();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        q3 = new javax.swing.JTextField();
        opt1 = new javax.swing.JCheckBox();
        opt2 = new javax.swing.JCheckBox();
        opt3 = new javax.swing.JCheckBox();
        opt4 = new javax.swing.JCheckBox();
        opt5 = new javax.swing.JCheckBox();
        jLabel3 = new javax.swing.JLabel();
        timer = new javax.swing.JLabel();
        back = new javax.swing.JButton();
        next = new javax.swing.JButton();

        jCheckBox6.setText("jCheckBox6");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 255));
        jLabel1.setText("Verbal Reasoning:");

        pass.setEditable(false);
        pass.setColumns(20);
        pass.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        pass.setLineWrap(true);
        pass.setRows(2);
        jScrollPane1.setViewportView(pass);

        jPanel1.setLayout(new javax.swing.BoxLayout(jPanel1, javax.swing.BoxLayout.LINE_AXIS));

        q3.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N

        opt5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opt5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(98, 98, 98)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(opt5)
                    .addComponent(opt4)
                    .addComponent(opt3)
                    .addComponent(opt2)
                    .addComponent(opt1))
                .addContainerGap(365, Short.MAX_VALUE))
            .addComponent(q3)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(q3, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(opt1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(opt2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(opt3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(opt4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(opt5)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setText("Time:");

        timer.setFont(new java.awt.Font("DS-Digital", 1, 36)); // NOI18N
        timer.setForeground(new java.awt.Color(255, 0, 0));
        timer.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        timer.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                timerPropertyChange(evt);
            }
        });

        back.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        back.setText("<<Back");
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });

        next.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        next.setText("Next>>");
        next.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(back, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(next, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
            .addGroup(layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 131, Short.MAX_VALUE)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(timer, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(10, 10, 10))))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(timer, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(back)
                    .addComponent(next)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void opt5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opt5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_opt5ActionPerformed

    private void nextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextActionPerformed
        // TODO add your handling code here:
        try {
            
            if(opt1.isSelected()) arr[c-3][0]=true;
            if(opt2.isSelected()) arr[c-3][1]=true;
            if(opt3.isSelected()) arr[c-3][2]=true;
            if(opt4.isSelected()) arr[c-3][3]=true;
            if(opt5.isSelected()) arr[c-3][4]=true;
            opt1.setSelected(false);
            opt2.setSelected(false);
            opt3.setSelected(false);
            opt4.setSelected(false);
            opt5.setSelected(false);
            c++;
            
            if(c>7){
               int dig=JOptionPane.showConfirmDialog(this,"Do you want to submit this section?","GRE Exam",JOptionPane.YES_NO_OPTION);
               if(dig==JOptionPane.YES_OPTION){
                try {
                    FileWriter fw=new FileWriter("src/Resources/ans"+roll+".txt",true);
                    BufferedWriter bw=new BufferedWriter(fw);
                    bw.append("Verbal Reasoning:\n\n");
                    for(int i=0;i<5;i++){
                        bw.append(String.valueOf(i+1)+"---->> ");
                        for(int j=0;j<5;j++) bw.append(arr[i][j]+" ");
                        bw.append("\n");
                        t.kill();
                        bw.flush();
                    }
                    bw.flush();
                    
                    this.setVisible(false);
                    QR_q1 page=new QR_q1(roll);
                    page.setSize(this.getSize());
                    page.out=out;
                    page.setVisible(true);
                    this.dispose();

                } catch (FileNotFoundException ex) {
                    Logger.getLogger(AnalyticExam1.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(AnalyticExam1.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                }
               else c=7;
               
                
            }
            if(c<=7){
            if(arr[c-3][0]) opt1.setSelected(true);
            if(arr[c-3][1]) opt2.setSelected(true);
            if(arr[c-3][2]) opt3.setSelected(true);
            if(arr[c-3][3]) opt4.setSelected(true);
            if(arr[c-3][4]) opt5.setSelected(true);
            FileReader fr=new FileReader(String.format("%s%d","src/Questions/Question",c));
            BufferedReader br=new BufferedReader(fr);
            String s="";
                
                while((s=(String)br.readLine()).compareTo("Question:")!=0){
                       pass.setText(s);
                   }
                
                if(s.equals("Question:")){
                   s=(String)br.readLine();
                   q3.setText(s);
                }
                s=(String)br.readLine();
                opt1.setText(s);
                s=(String)br.readLine();
                opt2.setText(s);
                s=(String)br.readLine();
                opt3.setText(s);
                s=(String)br.readLine();
                opt4.setText(s);
                s=(String)br.readLine();
                opt5.setText(s);
            }
  
        } catch (FileNotFoundException ex) {
            Logger.getLogger(AnalyticExam1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(AnalyticExam1.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_nextActionPerformed

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        // TODO add your handling code here:
        try {
            if(opt1.isSelected()) arr[c-3][0]=true;
            if(opt2.isSelected()) arr[c-3][1]=true;
            if(opt3.isSelected()) arr[c-3][2]=true;
            if(opt4.isSelected()) arr[c-3][3]=true;
            if(opt5.isSelected()) arr[c-3][4]=true;
            
            opt1.setSelected(false);
            opt2.setSelected(false);
            opt3.setSelected(false);
            opt4.setSelected(false);
            opt5.setSelected(false);
            
            c--;
            if(c<3) c=3;
            
            if(arr[c-3][0]) opt1.setSelected(true);
            if(arr[c-3][1]) opt2.setSelected(true);
            if(arr[c-3][2]) opt3.setSelected(true);
            if(arr[c-3][3]) opt4.setSelected(true);
            if(arr[c-3][4]) opt5.setSelected(true);
            FileReader fr=new FileReader(String.format("src/Questions/Question"+c));
            BufferedReader br=new BufferedReader(fr);
            String s=null;
                
                while((s=(String)br.readLine()).compareTo("Question:")!=0){
                       pass.setText(s);
                   }
                
                if(s.equals("Question:")){
                   s=(String)br.readLine();
                   q3.setText(s);
                }
                
                    s=(String)br.readLine();
                    
                    opt1.setText(s);
                    s=(String)br.readLine();
                    opt2.setText(s);
                    s=(String)br.readLine();
                    opt3.setText(s);
                    s=(String)br.readLine();
                    opt4.setText(s);
                    s=(String)br.readLine();
                    opt5.setText(s);
  
        } catch (FileNotFoundException ex) {
            Logger.getLogger(AnalyticExam1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(AnalyticExam1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_backActionPerformed

    private void timerPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_timerPropertyChange
        // TODO add your handling code here:
        if(timer.getText().equals("Time is UP!")){
            JOptionPane pane = new JOptionPane("Time is UP!!", JOptionPane.INFORMATION_MESSAGE);
            final JDialog dialog = pane.createDialog(this, "GRE Exam");
            new Thread(new Runnable()
            {
              public void run()
              {
                    try
                    {
                      Thread.sleep(5000);
                      dialog.dispose();

                    }
                    catch ( Throwable th )
                    {
                    }
                }
            }).start(); 
            dialog.setVisible(true);
            try {
                    FileWriter fw=new FileWriter("src/Resources/ans"+roll+".txt",true);
                    BufferedWriter bw=new BufferedWriter(fw);
                    bw.append("Verbal Reasoning:\n\n");
                    for(int i=0;i<5;i++){
                        bw.append((char) (i+1));
                        for(int j=0;j<5;j++) bw.append(arr[i][j]+" ");
                        bw.append("\n");
                        t.kill();
                        bw.flush();
                    }
                    bw.flush();
                    
                    this.setVisible(false);
                    QR_q1 page=new QR_q1(roll);
                    page.setSize(this.getSize());
                    page.out=out;
                    page.setVisible(true);

                } catch (FileNotFoundException ex) {
                    Logger.getLogger(AnalyticExam1.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(AnalyticExam1.class.getName()).log(Level.SEVERE, null, ex);
                }
        }
    }//GEN-LAST:event_timerPropertyChange

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VR_q1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VR_q1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VR_q1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VR_q1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                ///new VR_q1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton back;
    private javax.swing.JCheckBox jCheckBox6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton next;
    private javax.swing.JCheckBox opt1;
    private javax.swing.JCheckBox opt2;
    private javax.swing.JCheckBox opt3;
    private javax.swing.JCheckBox opt4;
    private javax.swing.JCheckBox opt5;
    private javax.swing.JTextArea pass;
    private javax.swing.JTextField q3;
    private javax.swing.JLabel timer;
    // End of variables declaration//GEN-END:variables
}
